package mvc.board.handler;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class WriteFormHandler implements CommandHandler {

	@Override
	public String execute(HttpServletRequest req, HttpServletResponse res) {

		// 제목글
		int num = 0;
		int ref = 1; // 그룹화 아이디
		int ref_step = 0; // 글 순서
		int ref_level = 0; // 글 레벨

		
		// 답변글

		// 게시글 번호가 있다면
		if (req.getParameter("num") != null) {
			num = Integer.parseInt(req.getParameter("num"));
			ref = Integer.parseInt(req.getParameter("ref"));
			ref_step = Integer.parseInt(req.getParameter("ref_step"));
			ref_level = Integer.parseInt(req.getParameter("ref_level"));

		}
		req.setAttribute("num", num);
		req.setAttribute("ref", ref);
		req.setAttribute("ref_step", ref_step);
		req.setAttribute("ref_level", ref_level);
		req.setAttribute("pageNum", req.getParameter("pageNum"));
		
		return "/board/writeForm.jsp";
	}
}
