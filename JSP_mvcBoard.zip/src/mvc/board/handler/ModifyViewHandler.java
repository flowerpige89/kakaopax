package mvc.board.handler;

import java.awt.Window;
import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mvc.board.dao.BoardDAO;
import mvc.board.dao.BoardDAOImpl;
import mvc.board.dto.BoardDTO;

public class ModifyViewHandler implements CommandHandler {

	@Override
	public String execute(HttpServletRequest req, HttpServletResponse res) {
		int num = Integer.parseInt(req.getParameter("num"));
		int pageNum	= Integer.parseInt(req.getParameter("pageNum"));
		String passwd = req.getParameter("passwd");
		
		// 싱글톤, 다형성 적용 (습관)
		BoardDAO mdao = BoardDAOImpl.getInstance();
		
		// 패스워드가 일치하면 cnt = 1, 패스워드가 일치하지 않으면 cnt = 0;
		int cnt = mdao.pwdCheck(num, passwd);
		
		if (cnt == 1) {
			BoardDTO bdto = mdao.getArticle(num);
			req.setAttribute("bdto", bdto);
			req.setAttribute("cnt", cnt);
			req.setAttribute("num", num);
			req.setAttribute("pageNum", pageNum);
		} else {
			return "/board/fail.jsp";
		}
		return "/board/modifyView.jsp";
	}
}