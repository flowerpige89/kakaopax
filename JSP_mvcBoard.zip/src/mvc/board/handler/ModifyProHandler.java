package mvc.board.handler;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mvc.board.dao.BoardDAO;
import mvc.board.dao.BoardDAOImpl;
import mvc.board.dto.BoardDTO;

public class ModifyProHandler implements CommandHandler {

	@Override
	public String execute(HttpServletRequest req, HttpServletResponse res) {
		
		int num = Integer.parseInt(req.getParameter("num"));
		int pageNum = Integer.parseInt(req.getParameter("pageNum"));
		
		
		// 1. 바구니 생성
			BoardDTO bdto = new BoardDTO();
		// 2. 바구니에 화면으로 부터 받은값을 담는다.
			bdto.setNum(Integer.parseInt(req.getParameter("num")));
			bdto.setSubject(req.getParameter("subject"));
			bdto.setContent(req.getParameter("content"));
			bdto.setPasswd(req.getParameter("passwd"));
			
		// 3. dao 생성 (싱글톤, 다형성)
			BoardDAO bdao = BoardDAOImpl.getInstance();
			
			int cnt = bdao.update(bdto); // 게시글 수정
		// 4. 
		if (cnt == 1) {
			
			req.setAttribute("cnt", cnt);
			req.setAttribute("pageNum", pageNum);
		}
					
		return "/board/modifyPro.jsp";
	}

}
