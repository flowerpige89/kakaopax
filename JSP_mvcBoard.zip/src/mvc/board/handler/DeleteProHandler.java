package mvc.board.handler;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mvc.board.dao.BoardDAO;
import mvc.board.dao.BoardDAOImpl;

public class DeleteProHandler implements CommandHandler {

	@Override
	public String execute(HttpServletRequest req, HttpServletResponse res) {
		
		
		int num = Integer.parseInt(req.getParameter("num"));
		String passwd = req.getParameter("passwd");		
		int pageNum = Integer.parseInt(req.getParameter("pageNum"));
		
		BoardDAO bdao = BoardDAOImpl.getInstance();
		int pwdCnt = bdao.pwdCheck(num, passwd);
		
		if (pwdCnt != 0) {
			int deleteCnt = bdao.delete(num);
			req.setAttribute("deleteCnt", deleteCnt);
		}
		
		req.setAttribute("pwdCnt", pwdCnt);
		req.setAttribute("pageNum", pageNum);
		
		return "/board/deletePro.jsp";
	}

}
