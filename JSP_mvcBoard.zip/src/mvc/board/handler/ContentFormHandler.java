package mvc.board.handler;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mvc.board.dao.BoardDAO;
import mvc.board.dao.BoardDAOImpl;
import mvc.board.dto.BoardDTO;

public class ContentFormHandler implements CommandHandler {

	@Override
	public String execute(HttpServletRequest req, HttpServletResponse res) {
		
		// get 방식이나 input으로 값을 넘길경우 getParameter로 받는다.
		int num = Integer.parseInt(req.getParameter("num"));
		int pageNum = Integer.parseInt(req.getParameter("pageNum"));
		int number = Integer.parseInt(req.getParameter("number")); // DB글번호가아닌 현재의 넘버링한 글번호
		
		BoardDAO bdao = BoardDAOImpl.getInstance();
		
		BoardDTO bdto = bdao.getArticle(num);
		
		// 내가 쓴글이 아닌것만 조회수 증가
		
		if (!req.getRemoteAddr().equals(bdto.getIp())) {
			bdao.addReadCnt(num);
		}
		
		req.setAttribute("num", num);
		req.setAttribute("pageNum", pageNum);
		req.setAttribute("bdto", bdto);
		req.setAttribute("number", number);
		
		return "/board/contentForm.jsp";
	}

}
