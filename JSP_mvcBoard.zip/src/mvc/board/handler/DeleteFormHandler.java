package mvc.board.handler;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DeleteFormHandler implements CommandHandler {

	@Override
	public String execute(HttpServletRequest req, HttpServletResponse res) {
		
		req.setAttribute("num", req.getParameter("num"));
		req.setAttribute("pageNum", req.getParameter("pageNum"));
		
		return "/board/deleteForm.jsp";
	}
}