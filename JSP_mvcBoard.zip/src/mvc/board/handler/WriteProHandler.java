package mvc.board.handler;

import java.sql.Timestamp;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mvc.board.dao.BoardDAO;
import mvc.board.dao.BoardDAOImpl;
import mvc.board.dto.BoardDTO;

public class WriteProHandler implements CommandHandler {

	@Override
	public String execute(HttpServletRequest req, HttpServletResponse res) {

	BoardDTO bdto = new BoardDTO();
	
	bdto.setNum(Integer.parseInt(req.getParameter("num")));
	bdto.setWriter(req.getParameter("writer"));
	bdto.setPasswd(req.getParameter("passwd"));
	bdto.setSubject(req.getParameter("subject"));
	bdto.setContent(req.getParameter("content"));
	bdto.setRef(Integer.parseInt(req.getParameter("ref")));
	bdto.setRef_step(Integer.parseInt(req.getParameter("ref_step")));
	bdto.setRef_level(Integer.parseInt(req.getParameter("ref_level")));
	
	bdto.setReg_date(new Timestamp(System.currentTimeMillis())); // 타임스탬프 불러오기
	bdto.setIp(req.getRemoteAddr()); // 자기 아이피를 요쳥한다.
	
	BoardDAO bdao = BoardDAOImpl.getInstance();
	
	int cnt = bdao.Insert(bdto);
	
	req.setAttribute("cnt", cnt);
	req.setAttribute("pageNum", req.getParameter("pageNum"));
	
	return "/board/writePro.jsp";
	}

}
