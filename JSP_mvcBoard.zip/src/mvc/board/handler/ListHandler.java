package mvc.board.handler;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mvc.board.dao.BoardDAOImpl;
import mvc.board.dto.BoardDTO;

public class ListHandler implements CommandHandler {

	@Override
	public String execute(HttpServletRequest req, HttpServletResponse res) {

		int pageSize = 5; // 한 페이지당 출력할 게시글 수
		int pageBlock = 3; // 출력할 페이지 수
		int cnt = 0; // 글 개수
		int start = 0; // 현재 페이지 시작 rownum
		int end = 0; // 현재 페이지 끝 rownum
		int number = 0; // 출력할 글 번호
		String pageNum = null; // 페이지 번호
		int currentPage = 0; // 현재페이지
		int pageCount = 0; // 페이지 개수
		int startPage = 0; // 시작 페이지
		int endPage = 0; // 마지막 페이지

		BoardDAOImpl bdao = BoardDAOImpl.getInstance();

		cnt = bdao.getCount();

		pageNum = req.getParameter("pageNum"); // 페이지번호를 넘겨받는다.

		if (pageNum == null) {
			pageNum = "1";
		}

		currentPage = Integer.parseInt(pageNum);

		pageCount = (cnt / pageSize) + (cnt % pageSize > 0 ? 1 : 0);

		start = (currentPage - 1) * pageSize + 1; // (5-1) * 10 + 1 = 41
		end = start + pageSize - 1; // 41 + 10 - 1 = 50

		if (end > cnt)
			end = cnt;

		// 글번호
		number = cnt - (currentPage - 1) * pageSize;

		if (cnt > 0) {
			ArrayList<BoardDTO> articles = bdao.getArticles(start, end);
			req.setAttribute("articles", articles);
		}

		startPage = (currentPage / pageBlock) * pageBlock + 1; // (5 / 3) * 3 +
																// 1 = 4
		if (currentPage % pageBlock == 0)
			startPage -= pageBlock; // if(5 % 3)

		endPage = startPage + pageBlock - 1; // 4 + 3 - 1 = 6;
		if (endPage > pageCount)
			endPage = pageCount;

		req.setAttribute("cnt", cnt);
		req.setAttribute("number", number);
		req.setAttribute("pageNum", pageNum);

		if (cnt > 0) {
			req.setAttribute("currentPage", currentPage);
			req.setAttribute("startPage", startPage);
			req.setAttribute("endPage", endPage);
			req.setAttribute("pageCount", pageCount);
			req.setAttribute("pageBlock", pageBlock);
		}

		return "/board/list.jsp";
	}

}
