package mvc.board.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import mvc.board.dto.BoardDTO;

public class BoardDAOImpl implements BoardDAO {

	DataSource dataSource;

	private static BoardDAOImpl instance = new BoardDAOImpl();

	public static BoardDAOImpl getInstance() {
		return instance;
	}

	public BoardDAOImpl() {
		try {
			Context context = new InitialContext();

			dataSource = (DataSource) context.lookup("java:comp/env/mvc/Oracle11g");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public int getCount() {
		int cnt = 0;

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = dataSource.getConnection();

			String sql = "SELECT count(*) FROM board"; // board 테이블에서 게시글의 갯수를
														// 카운트함
			pstmt = conn.prepareStatement(sql);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				cnt = rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
		}
		return cnt;
	}

	// 게시글 목록 조회
	@Override
	public ArrayList<BoardDTO> getArticles(int start, int end) {

		ArrayList<BoardDTO> articles = null;

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = dataSource.getConnection();

			// 서브쿼리
			String sql = "SELECT * FROM (SELECT num, writer, passwd, subject, content, readCnt,"
					+ " 								   ref, ref_step, ref_level, reg_date, ip, rownum rnum "
					+ "FROM (" + "SELECT * FROM board ORDER BY ref DESC, ref_step ASC" + "         )" + "    )"
					+ "WHERE rnum >=? AND rnum <=?";

			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, start);
			pstmt.setInt(2, end);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				articles = new ArrayList<BoardDTO>(end - start + 1);

				do {
					BoardDTO bdto = new BoardDTO();

					// data를 읽어서 rs를 작은 바구니 (dto)에 담는다(set)
					bdto.setNum(rs.getInt("num"));
					bdto.setWriter(rs.getString("writer"));
					bdto.setPasswd(rs.getString("passwd"));
					bdto.setSubject(rs.getString("subject"));
					bdto.setContent(rs.getString("content"));
					bdto.setReadCnt(rs.getInt("readCnt"));
					bdto.setRef(rs.getInt("ref"));
					bdto.setRef_step(rs.getInt("ref_step"));
					bdto.setRef_level(rs.getInt("ref_level"));
					bdto.setReg_date(rs.getTimestamp("reg_date"));
					bdto.setIp(rs.getString("ip"));

					// 큰바구니(articlse)에 작은바구니(bdto)를 담는다.
					articles.add(bdto);

				} while (rs.next());
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
		}
		return articles;
	}

	@Override
	public int Insert(BoardDTO bdto) {
		int cnt = 0;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = dataSource.getConnection();

			int num = bdto.getNum();
			int ref = bdto.getRef(); // ref = 답변글의 글번호 num과 같아야한다.
			int ref_step = bdto.getRef_step();
			int ref_level = bdto.getRef_level();
			String sql;

			// 제목글인 경우

			// 글쓰기
			if (num == 0) {
				sql = "SELECT MAX(num) FROM board";

				pstmt = conn.prepareStatement(sql);
				rs = pstmt.executeQuery();

				// 글이있는 경우
				// 글 쓰기 이므로 num : board_sql.nextval --> 글번호 최대값 + 1
				if (rs.next()) {
					ref = rs.getInt(1) + 1; // ref: 그룹화 아이디 = 글번호 최대값 + 1
											// MAX(num)
					// 글이없는 경우
				} else {
					ref = 1;
				}
				ref_step = 0;
				ref_level = 0;

				// 답변글인 경우
			} else {
				// ref 값은 같아야하고 ref_step 기존값보다 큰경우에 업데이트 시켜라
				sql = "UPDATE board SET ref_step= ref_step +1 WHERE ref= ? AND ref_step > ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, ref);
				pstmt.setInt(2, ref_step);
				pstmt.executeUpdate();

				ref_step++;
				ref_level++;
			}
			sql = "INSERT INTO board(num, writer, passwd, subject, content, readCnt, ref, ref_step, ref_level, reg_date, ip) "
					+ "VALUES(board_seq.nextval,?,?,?,?,0,?,?,?,?,?)";

			pstmt.close();
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, bdto.getWriter());
			pstmt.setString(2, bdto.getPasswd());
			pstmt.setString(3, bdto.getSubject());
			pstmt.setString(4, bdto.getContent());
			pstmt.setInt(5, ref);
			pstmt.setInt(6, ref_step);
			pstmt.setInt(7, ref_level);
			pstmt.setTimestamp(8, bdto.getReg_date());
			pstmt.setString(9, bdto.getIp());

			cnt = pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
		}

		return cnt;
	}

	// 상세 페이지, 수정내역 페이지
	@Override
	public BoardDTO getArticle(int num) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		BoardDTO bdto = null;

		try {
			conn = dataSource.getConnection();
			String sql = "SELECT * FROM board WHERE num= ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				bdto = new BoardDTO();

				bdto.setNum(rs.getInt("num"));
				bdto.setWriter(rs.getString("writer"));
				bdto.setPasswd(rs.getString("passwd"));
				bdto.setSubject(rs.getString("subject"));
				bdto.setContent(rs.getString("content"));
				bdto.setReadCnt(rs.getInt("readCnt"));
				bdto.setRef(rs.getInt("ref"));
				bdto.setRef_step(rs.getInt("ref_step"));
				bdto.setRef_level(rs.getInt("ref_level"));
				bdto.setReg_date(rs.getTimestamp("reg_date"));
				bdto.setIp(rs.getString("ip"));

			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
		}
		return bdto;
	}

	@Override
	public void addReadCnt(int num) {

		Connection conn = null;
		PreparedStatement pstmt = null;

		try {
			conn = dataSource.getConnection();

			String sql = "UPDATE board SET readCnt= readCnt+1 WHERE num= ?";

			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
		}
	}

	@Override
	public int pwdCheck(int num, String passwd) {
		int cnt = 0;

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = dataSource.getConnection();
			String sql = "SELECT * FROM board WHERE num= ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				// 패스워드가 일치하면
				if (passwd.equals(rs.getString("passwd"))) {
					cnt = 1;

					// 패스워드가 일치하지 않으면
				} else {
					cnt = 0;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
		}

		return cnt;
	}

	// 게시글 수정
	@Override
	public int update(BoardDTO bdto) {
		int cnt = 0;

		Connection conn = null;
		PreparedStatement pstmt = null;

		try {
			conn = dataSource.getConnection();
			String sql = "UPDATE board SET subject= ?, content= ?, passwd= ? WHERE num= ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, bdto.getSubject());
			pstmt.setString(2, bdto.getContent());
			pstmt.setString(3, bdto.getPasswd());
			pstmt.setInt(4, bdto.getNum());

			cnt = pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}

		return cnt;
	}

	// 게시글 삭제
	@Override
	public int delete(int num) { // int num 변수명 달라도 상관없음.
		int cnt = 0;

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql;

		try {
			conn = dataSource.getConnection();
			sql = "SELECT * FROM board WHERE num= ?";
			pstmt = conn.prepareStatement(sql);

			pstmt.setInt(1, num);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				int ref = rs.getInt("ref");
				int ref_step = rs.getInt("ref_step");
				int ref_level = rs.getInt("ref_level");

				sql = "SELECT * FROM board WHERE ref= ? AND ref_step= ?+1 AND ref_level > ?";
				pstmt.close();
				
				pstmt = conn.prepareStatement(sql);
				
				pstmt.setInt(1, ref);
				pstmt.setInt(2, ref_step);
				pstmt.setInt(3, ref_level);
				
				rs.close();
				
				rs = pstmt.executeQuery();
				
				// 답글이 있는경우
				if (rs.next()) {
					cnt = -1;
				} else { // 답글이 없는 경우
					sql = "UPDATE board SET ref_step= ref_step -1 WHERE ref= ? AND ref_step > ?";
					pstmt.close();
					pstmt = conn.prepareStatement(sql);
					pstmt.setInt(1, ref);
					pstmt.setInt(2, ref_step);

					pstmt.executeUpdate();

					sql = "DELETE FROM board WHERE num= ?";
					pstmt.close();
					pstmt = conn.prepareStatement(sql);
					pstmt.setInt(1, num);
					
					cnt = pstmt.executeUpdate();
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
		}

		return cnt;
	}
}