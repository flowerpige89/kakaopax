
CREATE TABLE board (
num NUMBER(5) PRIMARY KEY,     -- 글번호
writer VARCHAR2(20) NOT NULL,   -- 작성자
passwd VARCHAR2(10) NOT NULL, -- 비밀번호
subject VARCHAR2(50) NOT NULL, -- 글제목
content VARCHAR2(500),              -- 글내용
readCnt NUMBER(5) DEFAULT 0,    -- 조회수
ref NUMBER(5) DEFAULT 0,           -- 그룹화 아이디
ref_step NUMBER(5) DEFAULT 0,    -- 글순서
ref_level NUMBER(5) DEFAULT 0,   -- 글레벨
email VARCHAR2(30) NOT NULL,   -- 이메일
reg_date TIMESTAMP,                 -- 작성일
ip VARCHAR2(15)                        -- 아이피
);

desc board;

SELECT num FROM board WHERE num=1;

SELECT * FROM board;

CREATE SEQUENCE board_seq
START WITH 1
INCREMENT BY 1
MAXVALUE 99999;

DROP SEQUENCE board_seq;

INSERT INTO board(num, writer, passwd, subject, content, readCnt, ref, ref_step, ref_level, email, reg_date, ip) 
values(board_seq.nextval,'최두순','5678','성공입니다.','고고싱', 0, board_seq.currval, 0, 0, 'honam@naver.com', sysdate,'192.0.0.1');

INSERT INTO board(num, writer, passwd, subject, content, readCnt, ref, ref_step, ref_level, email, reg_date, ip) 
values(board_seq.nextval,'최두조','7810','성공입니다.','고고싱', 0, board_seq.currval, 0, 0, 'honam@naver.com', sysdate,'192.0.0.2');

INSERT INTO board(num, writer, passwd, subject, content, readCnt, ref, ref_step, ref_level, email, reg_date, ip) 
values(board_seq.nextval,'최두식','8090','성공입니다.','고고싱', 0, board_seq.currval, 0, 0, 'honam@naver.com', sysdate,'192.0.0.3');

INSERT INTO board(num, writer, passwd, subject, content, readCnt, ref, ref_step, ref_level, email, reg_date, ip) 
values(board_seq.nextval,'최두숙','8948','성공입니다.','고고싱', 0, board_seq.currval, 0, 0, 'honam@naver.com', sysdate,'192.0.0.4');

INSERT INTO board(num, writer, passwd, subject, content, readCnt, ref, ref_step, ref_level, email, reg_date, ip) 
values(board_seq.nextval,'최두자','4894','성공입니다.','고고싱', 0, board_seq.currval, 0, 0, 'honam@naver.com', sysdate,'192.0.0.5');

INSERT INTO board(num, writer, passwd, subject, content, readCnt, ref, ref_step, ref_level, email, reg_date, ip) 
values(board_seq.nextval,'최두주','6152','성공입니다.','고고싱', 0, board_seq.currval, 0, 0, 'honam@naver.com', sysdate,'192.0.0.6');

INSERT INTO board(num, writer, passwd, subject, content, readCnt, ref, ref_step, ref_level, email, reg_date, ip) 
values(board_seq.nextval,'최두신','1254','성공입니다.','고고싱', 0, board_seq.currval, 0, 0, 'honam@naver.com', sysdate,'192.0.0.7');

INSERT INTO board(num, writer, passwd, subject, content, readCnt, ref, ref_step, ref_level, email, reg_date, ip) 
values(board_seq.nextval,'최두찬','0052','성공입니다.','고고싱', 0, board_seq.currval, 0, 0, 'honam@naver.com', sysdate,'192.0.0.8');
ㄴ
INSERT INTO board(num, writer, passwd, subject, content, readCnt, ref, ref_step, ref_level, email, reg_date, ip) 
values(board_seq.nextval,'최두현','4890','성공입니다.','고고싱', 0, board_seq.currval, 0, 0, 'honam@naver.com', sysdate,'192.0.0.9');

INSERT INTO board(num, writer, passwd, subject, content, readCnt, ref, ref_step, ref_level, email, reg_date, ip) 
values(board_seq.nextval,'최두호','2342','성공입니다.','고고싱', 0, board_seq.currval, 0, 0, 'honam@naver.com', sysdate,'192.0.0.10');

INSERT INTO board values(board_seq.nextval, '', '1234','안녕하세요.', '반갑습니다.', 0, 0, 0, 0, 'sunnam@naver.com',sysdate,19216802);

commit;

DESC board;

SELECT * FROM (SELECT num, writer, passwd, subject, content, readCnt, ref, ref_step, ref_level, email, reg_date, ip, rownum rnum 
FROM (
            SELECT * FROM board ORDER BY ref DESC, ref_step ASC
      )
)
WHERE rnum >= 1 AND rnum <=2;