package mvc.board.dao;

import java.util.ArrayList;

import mvc.board.dto.BoardDTO;

public interface BoardDAO {
	
public int getCount(); // 게시글 건수

public ArrayList<BoardDTO> getArticles(int start, int end); // 게시글 목록 조회

public int Insert(BoardDTO bdto);

public BoardDTO getArticle(int num);

public void addReadCnt(int num); // 내가 쓴글이 아닌것만 조회수 증가

public int pwdCheck(int num, String passwd); // 비밀번호 확인

public int update(BoardDTO bdto); // 게시글 수정

public int delete(int num); // 게시글 삭제

}
