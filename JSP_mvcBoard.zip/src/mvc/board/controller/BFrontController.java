package mvc.board.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mvc.board.handler.CommandHandler;
import mvc.board.handler.ContentFormHandler;
import mvc.board.handler.DeleteFormHandler;
import mvc.board.handler.DeleteProHandler;
import mvc.board.handler.ListHandler;
import mvc.board.handler.ModifyFormHandler;
import mvc.board.handler.ModifyProHandler;
import mvc.board.handler.ModifyViewHandler;
import mvc.board.handler.WriteFormHandler;
import mvc.board.handler.WriteProHandler;

@WebServlet("*.do")
public class BFrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public BFrontController() {
		super();
	}

	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

		ActionDo(req, res);
	}

	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

		ActionDo(req, res);
	}

	public void ActionDo(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

		req.setCharacterEncoding("UTF-8");

		String viewPage = null;
		CommandHandler handler = null;

		String uri = req.getRequestURI(); // JSP mvcBoard/list.do
		String contextPath = req.getContextPath();
		String url = uri.substring(contextPath.length());


			// 글목록
		if (url.equals("/list.do")) {

			handler = new ListHandler();

			viewPage = handler.execute(req, res);

			// 글쓰기 페이지
		} else if (url.equals("/writeForm.do")) {

			handler = new WriteFormHandler();

			viewPage = handler.execute(req, res);

			// 글쓰기 처리 페이지
			
		} else if (url.equals("/writePro.do")) {

			handler = new WriteProHandler();

			viewPage = handler.execute(req, res);

			// 상세 페이지
		} else if (url.equals("/contentForm.do")) {

			handler = new ContentFormHandler();

			viewPage = handler.execute(req, res);
		
		} else if (url.equals("/modifyForm.do")) {
		
			handler = new ModifyFormHandler();
			
			viewPage = handler.execute(req, res);
			
		} else if (url.equals("/modifyView.do")) {
			
			handler = new ModifyViewHandler();
			
			viewPage = handler.execute(req, res);
			
		} else if (url.equals("/modifyPro.do")) {
			
			handler = new ModifyProHandler();
			
			viewPage = handler.execute(req, res);
			
		} else if (url.equals("/deleteForm.do")) {
			
			handler = new DeleteFormHandler();
			
			viewPage = handler.execute(req, res);
			
		} else if (url.equals("/deletePro.do")) {
			
			handler = new DeleteProHandler();
			
			viewPage = handler.execute(req, res);
			
		} else {
			viewPage = "/board/default.jsp"; // jsp 페이지에서 error 페이지 처리
		}

		RequestDispatcher dispatcher = req.getRequestDispatcher(viewPage); // viewPage로
																			// 이동
																			// 필수!!!!
		dispatcher.forward(req, res);

	}
}